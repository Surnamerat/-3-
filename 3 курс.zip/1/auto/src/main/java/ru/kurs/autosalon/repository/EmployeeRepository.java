package ru.kurs.autosalon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.kurs.autosalon.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {}
