package ru.kurs.autosalon.model;

public enum Priority {
    LOW("Низкий"), NORMAL("Обычный"), HIGH("Высокий"), URGENT("Срочный");
    private final String title;
    Priority(String title){this.title=title;}
    public String getTitle(){return title;}
}
