package ru.kurs.autosalon.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.kurs.autosalon.model.Priority;
import ru.kurs.autosalon.model.RequestStatus;
import ru.kurs.autosalon.model.ServiceRequest;
import ru.kurs.autosalon.repository.CarRepository;
import ru.kurs.autosalon.repository.ClientRepository;
import ru.kurs.autosalon.repository.EmployeeRepository;
import ru.kurs.autosalon.service.ServiceRequestService;

@Controller
@RequestMapping("/requests")
public class ServiceRequestController {
    private final ServiceRequestService service;
    private final ClientRepository clients;
    private final CarRepository cars;
    private final EmployeeRepository employees;
    public ServiceRequestController(ServiceRequestService service, ClientRepository clients, CarRepository cars, EmployeeRepository employees) {this.service=service;this.clients=clients;this.cars=cars;this.employees=employees;}
    @GetMapping public String list(Model model){ model.addAttribute("requests", service.findAll()); return "requests/list"; }
    @GetMapping("/new") public String createForm(Model model){ fillForm(model, new ServiceRequest()); return "requests/form"; }
    @GetMapping("/{id}") public String details(@PathVariable Long id, Model model){ model.addAttribute("request", service.findById(id)); return "requests/details"; }
    @GetMapping("/{id}/edit") public String editForm(@PathVariable Long id, Model model){ fillForm(model, service.findById(id)); return "requests/form"; }
    @PostMapping public String save(@Valid @ModelAttribute ServiceRequest request, BindingResult result, Model model){ if(result.hasErrors()){ fillForm(model, request); return "requests/form";} service.save(request); return "redirect:/requests"; }
    @PostMapping("/{id}/delete") public String delete(@PathVariable Long id){ service.delete(id); return "redirect:/requests"; }
    private void fillForm(Model model, ServiceRequest request){
        model.addAttribute("request", request);
        model.addAttribute("clients", clients.findAll());
        model.addAttribute("cars", cars.findAll());
        model.addAttribute("employees", employees.findAll());
        model.addAttribute("statuses", RequestStatus.values());
        model.addAttribute("priorities", Priority.values());
    }
}
