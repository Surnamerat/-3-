package ru.kurs.autosalon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.kurs.autosalon.model.RequestStatus;
import ru.kurs.autosalon.model.ServiceRequest;
import java.util.List;

public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, Long> {
    long countByStatus(RequestStatus status);
    List<ServiceRequest> findByCarIdOrderByCreatedAtDesc(Long carId);
    List<ServiceRequest> findByClientIdOrderByCreatedAtDesc(Long clientId);
}
