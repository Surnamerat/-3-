package ru.kurs.autosalon.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "cars")
public class Car {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) private Client client;
    @NotBlank private String brand;
    @NotBlank private String model;
    private Integer productionYear;
    private String licensePlate;
    private String vin;
    private Integer mileage;
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public Client getClient(){return client;} public void setClient(Client client){this.client=client;}
    public String getBrand(){return brand;} public void setBrand(String brand){this.brand=brand;}
    public String getModel(){return model;} public void setModel(String model){this.model=model;}
    public Integer getProductionYear(){return productionYear;} public void setProductionYear(Integer productionYear){this.productionYear=productionYear;}
    public String getLicensePlate(){return licensePlate;} public void setLicensePlate(String licensePlate){this.licensePlate=licensePlate;}
    public String getVin(){return vin;} public void setVin(String vin){this.vin=vin;}
    public Integer getMileage(){return mileage;} public void setMileage(Integer mileage){this.mileage=mileage;}
    public String getTitle(){return brand + " " + model + (licensePlate == null || licensePlate.isBlank() ? "" : " (" + licensePlate + ")");}

    public void setYear(int i) {
    }
}
