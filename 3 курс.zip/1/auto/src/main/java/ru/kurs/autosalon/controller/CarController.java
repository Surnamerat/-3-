package ru.kurs.autosalon.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.kurs.autosalon.model.Car;
import ru.kurs.autosalon.repository.CarRepository;
import ru.kurs.autosalon.repository.ClientRepository;
import ru.kurs.autosalon.service.ServiceRequestService;

@Controller
@RequestMapping("/cars")
public class CarController {
    private final CarRepository repository;
    private final ClientRepository clients;
    private final ServiceRequestService requests;
    public CarController(CarRepository repository, ClientRepository clients, ServiceRequestService requests) {this.repository=repository;this.clients=clients;this.requests=requests;}
    @GetMapping public String list(Model model){ model.addAttribute("cars", repository.findAll()); return "cars/list"; }
    @GetMapping("/new") public String createForm(Model model){ model.addAttribute("car", new Car()); model.addAttribute("clients", clients.findAll()); return "cars/form"; }
    @GetMapping("/{id}") public String details(@PathVariable Long id, Model model){ Car car = repository.findById(id).orElseThrow(); model.addAttribute("car", car); model.addAttribute("requests", requests.findByCar(id)); return "cars/details"; }
    @GetMapping("/{id}/edit") public String editForm(@PathVariable Long id, Model model){ model.addAttribute("car", repository.findById(id).orElseThrow()); model.addAttribute("clients", clients.findAll()); return "cars/form"; }
    @PostMapping public String save(@Valid @ModelAttribute Car car, BindingResult result, Model model){ if(result.hasErrors()){ model.addAttribute("clients", clients.findAll()); return "cars/form";} repository.save(car); return "redirect:/cars"; }
    @PostMapping("/{id}/delete") public String delete(@PathVariable Long id){ repository.deleteById(id); return "redirect:/cars"; }
}
