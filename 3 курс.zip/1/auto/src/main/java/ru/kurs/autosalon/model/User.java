package ru.kurs.autosalon.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "app_users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Column(unique = true)
    private String username;
    @NotBlank
    private String password;
    @NotBlank
    private String fullName;
    @Enumerated(EnumType.STRING)
    private Role role;
    private boolean enabled = true;
    public User() {}
    public User(String username, String password, String fullName, Role role) {this.username=username;this.password=password;this.fullName=fullName;this.role=role;}
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getUsername(){return username;} public void setUsername(String username){this.username=username;}
    public String getPassword(){return password;} public void setPassword(String password){this.password=password;}
    public String getFullName(){return fullName;} public void setFullName(String fullName){this.fullName=fullName;}
    public Role getRole(){return role;} public void setRole(Role role){this.role=role;}
    public boolean isEnabled(){return enabled;} public void setEnabled(boolean enabled){this.enabled=enabled;}
}
