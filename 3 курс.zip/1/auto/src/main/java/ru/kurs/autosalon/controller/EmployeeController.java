package ru.kurs.autosalon.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.kurs.autosalon.model.Employee;
import ru.kurs.autosalon.repository.EmployeeRepository;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
    private final EmployeeRepository repository;
    public EmployeeController(EmployeeRepository repository) { this.repository = repository; }
    @GetMapping public String list(Model model){ model.addAttribute("employees", repository.findAll()); return "employees/list"; }
    @GetMapping("/new") public String createForm(Model model){ model.addAttribute("employee", new Employee()); return "employees/form"; }
    @GetMapping("/{id}/edit") public String editForm(@PathVariable Long id, Model model){ model.addAttribute("employee", repository.findById(id).orElseThrow()); return "employees/form"; }
    @PostMapping public String save(@Valid @ModelAttribute Employee employee, BindingResult result){ if(result.hasErrors()) return "employees/form"; repository.save(employee); return "redirect:/employees"; }
    @PostMapping("/{id}/delete") public String delete(@PathVariable Long id){ repository.deleteById(id); return "redirect:/employees"; }
}
