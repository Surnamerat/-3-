package ru.kurs.autosalon.model;

public enum RequestStatus {
    NEW("Новая"), ACCEPTED("Принята"), DIAGNOSTICS("В диагностике"), REPAIR("В ремонте"), WAITING_PARTS("Ожидает запчасти"), DONE("Выполнена"), CLOSED("Закрыта"), CANCELLED("Отменена");
    private final String title;
    RequestStatus(String title){this.title=title;}
    public String getTitle(){return title;}
}
