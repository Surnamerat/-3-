package ru.kurs.autosalon.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "service_requests")
public class ServiceRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) private Client client;
    @ManyToOne(optional = false) private Car car;
    @ManyToOne private Employee assignedEmployee;
    @NotBlank private String requestType;
    @Column(length = 2000) private String description;
    @Enumerated(EnumType.STRING) private RequestStatus status = RequestStatus.NEW;
    @Enumerated(EnumType.STRING) private Priority priority = Priority.NORMAL;
    private LocalDateTime createdAt;
    private LocalDateTime plannedAt;
    private LocalDateTime completedAt;
    @Column(length = 2000) private String resultComment;
    @PrePersist public void prePersist(){ if(createdAt == null) createdAt = LocalDateTime.now(); }
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public Client getClient(){return client;} public void setClient(Client client){this.client=client;}
    public Car getCar(){return car;} public void setCar(Car car){this.car=car;}
    public Employee getAssignedEmployee(){return assignedEmployee;} public void setAssignedEmployee(Employee assignedEmployee){this.assignedEmployee=assignedEmployee;}
    public String getRequestType(){return requestType;} public void setRequestType(String requestType){this.requestType=requestType;}
    public String getDescription(){return description;} public void setDescription(String description){this.description=description;}
    public RequestStatus getStatus(){return status;} public void setStatus(RequestStatus status){this.status=status;}
    public Priority getPriority(){return priority;} public void setPriority(Priority priority){this.priority=priority;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
    public LocalDateTime getPlannedAt(){return plannedAt;} public void setPlannedAt(LocalDateTime plannedAt){this.plannedAt=plannedAt;}
    public LocalDateTime getCompletedAt(){return completedAt;} public void setCompletedAt(LocalDateTime completedAt){this.completedAt=completedAt;}
    public String getResultComment(){return resultComment;} public void setResultComment(String resultComment){this.resultComment=resultComment;}
}
