package ru.kurs.autosalon.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import ru.kurs.autosalon.model.*;
import ru.kurs.autosalon.repository.*;

@Configuration
public class DatabaseInitializer {
    @Bean
    CommandLineRunner initData(UserRepository users, ClientRepository clients, CarRepository cars,
                               EmployeeRepository employees, ServiceRequestRepository requests,
                               PasswordEncoder encoder) {
        return args -> {
            if (users.count() == 0) {
                users.save(new User("admin", encoder.encode("admin123"), "Администратор", Role.ADMIN));
                users.save(new User("manager", encoder.encode("manager123"), "Менеджер сервиса", Role.MANAGER));
                users.save(new User("master", encoder.encode("master123"), "Мастер-приемщик", Role.MASTER));
            }
            if (clients.count() == 0) {
                Client c1 = new Client(); c1.setLastName("Иванов"); c1.setFirstName("Алексей"); c1.setPhone("+7 900 111-22-33"); c1.setEmail("ivanov@mail.ru"); clients.save(c1);
                Client c2 = new Client(); c2.setLastName("Петрова"); c2.setFirstName("Мария"); c2.setPhone("+7 900 444-55-66"); c2.setEmail("petrova@mail.ru"); clients.save(c2);
                Car car1 = new Car(); car1.setClient(c1); car1.setBrand("Toyota"); car1.setModel("Camry"); car1.setProductionYear(2020); car1.setLicensePlate("А123ВС"); car1.setVin("JTNB11HK000000001"); car1.setMileage(63500); cars.save(car1);
                Car car2 = new Car(); car2.setClient(c2); car2.setBrand("Kia"); car2.setModel("Rio"); car2.setProductionYear(2019); car2.setLicensePlate("М777ОР"); car2.setVin("Z94CB41AA00000002"); car2.setMileage(81200); cars.save(car2);
                Employee e1 = new Employee(); e1.setFullName("Сидоров Павел"); e1.setPosition("Мастер-приемщик"); e1.setPhone("+7 901 100-10-10"); employees.save(e1);
                Employee e2 = new Employee(); e2.setFullName("Кузнецов Игорь"); e2.setPosition("Автомеханик"); e2.setPhone("+7 901 200-20-20"); employees.save(e2);
                ServiceRequest r1 = new ServiceRequest(); r1.setClient(c1); r1.setCar(car1); r1.setRequestType("Плановое ТО"); r1.setDescription("Замена масла и фильтров"); r1.setPriority(Priority.NORMAL); r1.setStatus(RequestStatus.NEW); r1.setAssignedEmployee(e1); requests.save(r1);
                ServiceRequest r2 = new ServiceRequest(); r2.setClient(c2); r2.setCar(car2); r2.setRequestType("Диагностика"); r2.setDescription("Посторонний шум при торможении"); r2.setPriority(Priority.HIGH); r2.setStatus(RequestStatus.DIAGNOSTICS); r2.setAssignedEmployee(e2); requests.save(r2);
            }
        };
    }
}
