package ru.kurs.autosalon.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "clients")
public class Client {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank private String lastName;
    @NotBlank private String firstName;
    private String middleName;
    @NotBlank private String phone;
    private String email;
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getLastName(){return lastName;} public void setLastName(String lastName){this.lastName=lastName;}
    public String getFirstName(){return firstName;} public void setFirstName(String firstName){this.firstName=firstName;}
    public String getMiddleName(){return middleName;} public void setMiddleName(String middleName){this.middleName=middleName;}
    public String getPhone(){return phone;} public void setPhone(String phone){this.phone=phone;}
    public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
    public String getFullName(){return lastName + " " + firstName + (middleName == null || middleName.isBlank() ? "" : " " + middleName);}
}
