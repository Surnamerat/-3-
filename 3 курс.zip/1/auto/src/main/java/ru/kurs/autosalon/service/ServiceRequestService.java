package ru.kurs.autosalon.service;

import org.springframework.stereotype.Service;
import ru.kurs.autosalon.model.RequestStatus;
import ru.kurs.autosalon.model.ServiceRequest;
import ru.kurs.autosalon.repository.ServiceRequestRepository;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ServiceRequestService {
    private final ServiceRequestRepository repository;
    public ServiceRequestService(ServiceRequestRepository repository) { this.repository = repository; }
    public List<ServiceRequest> findAll(){ return repository.findAll(); }
    public ServiceRequest findById(Long id){ return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Обращение не найдено")); }
    public ServiceRequest save(ServiceRequest request){
        if (request.getStatus() == null) request.setStatus(RequestStatus.NEW);
        if (request.getStatus() == RequestStatus.CLOSED || request.getStatus() == RequestStatus.DONE) {
            if (request.getCompletedAt() == null) request.setCompletedAt(LocalDateTime.now());
        }
        return repository.save(request);
    }
    public void delete(Long id){ repository.deleteById(id); }
    public long countByStatus(RequestStatus status){ return repository.countByStatus(status); }
    public List<ServiceRequest> findByCar(Long carId){ return repository.findByCarIdOrderByCreatedAtDesc(carId); }
    public List<ServiceRequest> findByClient(Long clientId){ return repository.findByClientIdOrderByCreatedAtDesc(clientId); }
}
