package ru.kurs.autosalon.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ru.kurs.autosalon.model.Car;
import ru.kurs.autosalon.model.Client;
import ru.kurs.autosalon.model.Employee;
import ru.kurs.autosalon.repository.CarRepository;
import ru.kurs.autosalon.repository.ClientRepository;
import ru.kurs.autosalon.repository.EmployeeRepository;

@Configuration
public class WebConverters implements WebMvcConfigurer {
    private final ClientRepository clients;
    private final CarRepository cars;
    private final EmployeeRepository employees;
    public WebConverters(ClientRepository clients, CarRepository cars, EmployeeRepository employees) {
        this.clients = clients; this.cars = cars; this.employees = employees;
    }
    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new Converter<String, Client>() {
            @Override public Client convert(String source) { return source == null || source.isBlank() ? null : clients.findById(Long.valueOf(source)).orElse(null); }
        });
        registry.addConverter(new Converter<String, Car>() {
            @Override public Car convert(String source) { return source == null || source.isBlank() ? null : cars.findById(Long.valueOf(source)).orElse(null); }
        });
        registry.addConverter(new Converter<String, Employee>() {
            @Override public Employee convert(String source) { return source == null || source.isBlank() ? null : employees.findById(Long.valueOf(source)).orElse(null); }
        });
    }
}
