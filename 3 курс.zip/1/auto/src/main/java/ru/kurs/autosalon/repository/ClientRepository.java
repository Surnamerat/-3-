package ru.kurs.autosalon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.kurs.autosalon.model.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {}
