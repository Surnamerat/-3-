package ru.kurs.autosalon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.kurs.autosalon.model.RequestStatus;
import ru.kurs.autosalon.repository.CarRepository;
import ru.kurs.autosalon.repository.ClientRepository;
import ru.kurs.autosalon.repository.EmployeeRepository;
import ru.kurs.autosalon.service.ServiceRequestService;

@Controller
public class HomeController {
    private final ServiceRequestService requests;
    private final ClientRepository clients;
    private final CarRepository cars;
    private final EmployeeRepository employees;
    public HomeController(ServiceRequestService requests, ClientRepository clients, CarRepository cars, EmployeeRepository employees) {
        this.requests = requests; this.clients = clients; this.cars = cars; this.employees = employees;
    }
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("clientCount", clients.count());
        model.addAttribute("carCount", cars.count());
        model.addAttribute("employeeCount", employees.count());
        model.addAttribute("newCount", requests.countByStatus(RequestStatus.NEW));
        model.addAttribute("repairCount", requests.countByStatus(RequestStatus.REPAIR));
        model.addAttribute("diagnosticsCount", requests.countByStatus(RequestStatus.DIAGNOSTICS));
        model.addAttribute("closedCount", requests.countByStatus(RequestStatus.CLOSED));
        model.addAttribute("requests", requests.findAll());
        return "index";
    }
    @GetMapping("/login") public String login(){ return "login"; }
}
