package ru.kurs.autosalon.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.kurs.autosalon.model.Client;
import ru.kurs.autosalon.repository.ClientRepository;
import ru.kurs.autosalon.service.ServiceRequestService;

@Controller
@RequestMapping("/clients")
public class ClientController {
    private final ClientRepository repository;
    private final ServiceRequestService requests;
    public ClientController(ClientRepository repository, ServiceRequestService requests) { this.repository = repository; this.requests = requests; }
    @GetMapping public String list(Model model){ model.addAttribute("clients", repository.findAll()); return "clients/list"; }
    @GetMapping("/new") public String createForm(Model model){ model.addAttribute("client", new Client()); return "clients/form"; }
    @GetMapping("/{id}") public String details(@PathVariable Long id, Model model){
        Client client = repository.findById(id).orElseThrow();
        model.addAttribute("client", client);
        model.addAttribute("requests", requests.findByClient(id));
        return "clients/details";
    }
    @GetMapping("/{id}/edit") public String editForm(@PathVariable Long id, Model model){ model.addAttribute("client", repository.findById(id).orElseThrow()); return "clients/form"; }
    @PostMapping public String save(@Valid @ModelAttribute Client client, BindingResult result){ if(result.hasErrors()) return "clients/form"; repository.save(client); return "redirect:/clients"; }
    @PostMapping("/{id}/delete") public String delete(@PathVariable Long id){ repository.deleteById(id); return "redirect:/clients"; }
}
