package ru.kurs.autosalon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.kurs.autosalon.model.Car;
import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
    List<Car> findByClientId(Long clientId);
}
