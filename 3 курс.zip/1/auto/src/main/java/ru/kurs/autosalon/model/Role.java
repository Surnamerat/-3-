package ru.kurs.autosalon.model;

public enum Role {
    ADMIN, MANAGER, MASTER
}
