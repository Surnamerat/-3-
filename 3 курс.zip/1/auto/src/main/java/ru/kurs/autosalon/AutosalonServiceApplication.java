package ru.kurs.autosalon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutosalonServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(AutosalonServiceApplication.class, args);
    }
}
