package ru.kurs.autosalon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.kurs.autosalon.model.User;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}
